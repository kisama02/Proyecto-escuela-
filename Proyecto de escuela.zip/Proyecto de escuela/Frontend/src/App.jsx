import "./App.css";
import HomePage from "./components/HomePage";

function App() {
  return (
    <>
      <h1 className="text-center mb-5 my-bold">
       Escuela
      </h1>
      <HomePage />
    </>
  );
}

export default App;
